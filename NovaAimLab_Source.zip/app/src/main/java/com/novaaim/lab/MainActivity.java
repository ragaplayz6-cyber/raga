package com.novaaim.lab;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout content;
    private final String[] labels={"General","Red Dot","2× Scope","4× Scope","Sniper","Free Look"};
    private final int[] defaults={92,86,78,68,48,75};
    private final ArrayList<SeekBar> sliders=new ArrayList<>();
    private int cyan=Color.rgb(34,211,238), panel=Color.rgb(17,24,39), white=Color.rgb(248,250,252), muted=Color.rgb(148,163,184);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,11,20));
        ScrollView scroll=new ScrollView(this);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20),dp(20),dp(20),dp(32)); content.setBackgroundColor(Color.rgb(7,11,20));
        scroll.addView(content); setContentView(scroll);
        title("NOVA AIM LAB",28,cyan);
        text("Build consistent settings. Train smarter.",15,muted);
        spacer(18);
        section("SENSITIVITY LAB");
        text("Tune and save your personal practice profile.",14,muted);
        for(int i=0;i<labels.length;i++) slider(labels[i],i);
        Button save=button("SAVE PROFILE",cyan); save.setOnClickListener(v->saveProfile());
        spacer(20); section("TODAY'S AIM DRILL");
        TextView drill=textView(randomDrill(),17,white); drill.setPadding(dp(16),dp(18),dp(16),dp(18)); drill.setBackgroundColor(panel); content.addView(drill,matchWrap());
        Button next=button("GENERATE NEW DRILL",Color.rgb(139,92,246)); next.setOnClickListener(v->drill.setText(randomDrill()));
        spacer(20); section("QUICK CHECKLIST");
        card("01  WARM UP","5 minutes of slow tracking before speed.");
        card("02  CROSSHAIR","Keep aim at expected head height.");
        card("03  CONTROL","Use small adjustments; avoid panic swipes.");
        card("04  REVIEW","Change only one setting per session.");
        spacer(22); text("Nova Aim Lab is an independent training companion. It does not modify, inject into, or interact with any game.",12,muted);
        loadProfile();
    }
    private void slider(String name,int index){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(dp(14),dp(10),dp(14),dp(8)); row.setBackgroundColor(panel);
        TextView value=textView(name+"  •  "+defaults[index],15,white); row.addView(value,matchWrap());
        SeekBar bar=new SeekBar(this); bar.setMax(100); bar.setProgress(defaults[index]); bar.setProgressTintList(android.content.res.ColorStateList.valueOf(cyan));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){value.setText(name+"  •  "+p);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        row.addView(bar,matchWrap()); content.addView(row,matchWrap()); sliders.add(bar); spacer(8);
    }
    private void saveProfile(){
        getSharedPreferences("profile",MODE_PRIVATE).edit()
            .putString("values",joinValues()).apply();
        Toast.makeText(this,"Profile saved",Toast.LENGTH_SHORT).show();
    }
    private void loadProfile(){
        String raw=getSharedPreferences("profile",MODE_PRIVATE).getString("values","");
        if(raw.isEmpty())return; String[] v=raw.split(",");
        for(int i=0;i<Math.min(v.length,sliders.size());i++)try{sliders.get(i).setProgress(Integer.parseInt(v[i]));}catch(Exception ignored){}
    }
    private String joinValues(){StringBuilder s=new StringBuilder();for(SeekBar b:sliders){if(s.length()>0)s.append(",");s.append(b.getProgress());}return s.toString();}
    private String randomDrill(){
        String[] drills={
            "PRECISION • 8 MIN\nTap slowly between small targets. Accuracy goal: 85%.",
            "TRACKING • 10 MIN\nFollow a moving target smoothly without overcorrecting.",
            "FLICK CONTROL • 6 MIN\nAlternate near and far targets. Reset to center each time.",
            "REACTION • 7 MIN\nReact only after target appears. Prioritize clean first shots.",
            "MICRO ADJUST • 8 MIN\nStart near the target and practice tiny controlled corrections."
        }; return drills[new Random().nextInt(drills.length)];
    }
    private void card(String h,String d){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(15),dp(13),dp(15),dp(13));c.setBackgroundColor(panel);TextView a=textView(h,15,cyan);a.setTypeface(Typeface.DEFAULT_BOLD);c.addView(a);c.addView(textView(d,13,muted));content.addView(c,matchWrap());spacer(8);}
    private Button button(String t,int color){Button b=new Button(this);b.setText(t);b.setTextColor(Color.rgb(7,11,20));b.setTextSize(14);b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackgroundColor(color);content.addView(b,new LinearLayout.LayoutParams(-1,dp(52)));spacer(8);return b;}
    private void section(String s){TextView v=textView(s,18,white);v.setTypeface(Typeface.DEFAULT_BOLD);content.addView(v);spacer(8);}
    private void title(String s,int z,int c){TextView v=textView(s,z,c);v.setTypeface(Typeface.DEFAULT_BOLD);content.addView(v);}
    private void text(String s,int z,int c){content.addView(textView(s,z,c));}
    private TextView textView(String s,int z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);v.setLineSpacing(0,1.15f);return v;}
    private void spacer(int h){Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
    private LinearLayout.LayoutParams matchWrap(){return new LinearLayout.LayoutParams(-1,-2);}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
}
