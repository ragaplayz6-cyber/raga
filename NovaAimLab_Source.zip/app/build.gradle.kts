plugins {
    id("com.android.application")
}

android {
    namespace = "com.novaaim.lab"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.novaaim.lab"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
