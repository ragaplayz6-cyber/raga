# Nova Aim Lab

Clean, original Android gaming companion with no root, overlay, injection, game modification, or dangerous permissions.

## Build

1. Open the `NovaAimLab` folder in Android Studio.
2. Allow Gradle sync to complete.
3. Choose **Build → Build APK(s)**.
4. The debug APK will be created under `app/build/outputs/apk/debug/`.

## Build online without Android Studio

1. Upload this project to a new GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build Nova Aim Lab APK**.
4. Click **Run workflow**.
5. Download `NovaAimLab-APK` from the completed run's Artifacts section.

Package: `com.novaaim.lab`

Minimum Android version: Android 6.0 (API 23)
